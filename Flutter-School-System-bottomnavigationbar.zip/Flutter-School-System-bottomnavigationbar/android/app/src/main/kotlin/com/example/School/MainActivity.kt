package com.example.Schools

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
